---
title: TODO
module: topic-05
todo: <i class="fas fa-check-square" aria-hidden="true"></i>
permalink: /topic-05/todo-table-structure/
tags: uncategorized
---

<div class="row text-center">
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <div class="list-group-item hw-item-disabled">
          <img class="icon-hw" src="../img/hw-icon-duckett.svg" />
          <h4 class="list-group-item-heading">Duckett<br />Ch 06: pgs 126-143</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 12 minute reading</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <a href="https://www.quackit.com/html/html_table_generator.cfm" target="_blank" class="list-group-item">
          <i class="icon-hw fas fa-table" aria-hidden="true"></i>
          <h4 class="list-group-item-heading">Generate a Table</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 5 minute activity</p>
        </a>
      </div>
    </div>
  </div>
</div>
