---
title: Autofocus
module: topic-05
permalink: /topic-05/text-autofocus/
tags: autofocus, attribute, input, text
---

<div class="divider-heading"></div>
