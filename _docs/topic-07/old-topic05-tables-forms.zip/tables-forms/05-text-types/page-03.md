---
title: Password Input Type
module: topic-05
permalink: /topic-05/text-password/
tags: form, input, password, text
---

<div class="divider-heading"></div>
