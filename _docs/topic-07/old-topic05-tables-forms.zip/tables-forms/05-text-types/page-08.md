---
title: Size Attribute
module: topic-05
permalink: /topic-05/text-size/
tags: attribute, input, size, text
---

<div class="divider-heading"></div>
