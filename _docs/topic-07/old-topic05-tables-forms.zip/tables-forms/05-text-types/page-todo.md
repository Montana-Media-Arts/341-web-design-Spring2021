---
title: TODO
module: topic-05
todo: <i class="fas fa-check-square" aria-hidden="true"></i>
permalink: /topic-05/todo-text-input/
tags: uncategorized
---

<div class="row text-center">
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <div class="list-group-item hw-item-disabled">
          <img class="icon-hw" src="../img/hw-icon-duckett.svg" />
          <h4 class="list-group-item-heading">Duckett<br />Ch 07: pgs 152-154</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 1 minute reading</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <a href="https://codepen.io/Media-Ed-Online/pen/xXdvRw" target="_blank" class="list-group-item">
          <i class="icon-hw fab fa-codepen" aria-hidden="true"></i>
          <h4 class="list-group-item-heading">Code-Play: "Using Text-Type Inputs"</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 2 minute activity</p>
        </a>
      </div>
    </div>
  </div>
</div>
