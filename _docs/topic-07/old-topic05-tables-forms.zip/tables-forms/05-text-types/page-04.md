---
title: Textarea Input Type
module: topic-05
permalink: /topic-05/text-textarea/
tags: form, input, textarea, text
---

<div class="divider-heading"></div>
