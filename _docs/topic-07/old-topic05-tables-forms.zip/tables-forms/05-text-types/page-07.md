---
title: Placeholder Attribute
module: topic-05
permalink: /topic-05/text-placeholder/
tags: attribute, input, placeholder, text
---

<div class="divider-heading"></div>
