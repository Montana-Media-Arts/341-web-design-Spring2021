---
title: The Text Input Element
module: topic-05
permalink: /topic-05/text-input/
tags: elements, form, html, input, text
---

<div class="divider-heading"></div>
