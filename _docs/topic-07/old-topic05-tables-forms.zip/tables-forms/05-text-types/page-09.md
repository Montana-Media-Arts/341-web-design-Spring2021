---
title: Value
module: topic-05
permalink: /topic-05/text-value/
tags: attribute, input, text, value
---

<div class="divider-heading"></div>
