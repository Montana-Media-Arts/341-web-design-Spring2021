---
title: Plain Text Input Type
module: topic-05
permalink: /topic-05/text-plain/
tags: form, input, text
---

<div class="divider-heading"></div>
