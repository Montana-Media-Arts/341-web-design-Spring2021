---
title: Columns and Rows Attribute
module: topic-05
permalink: /topic-05/text-cols-rows/
tags: attribute, column, input, row, text
---

<div class="divider-heading"></div>
