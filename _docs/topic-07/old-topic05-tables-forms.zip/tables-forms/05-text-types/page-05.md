---
title: Maxlength Attribute
module: topic-05
permalink: /topic-05/text-maxlength/
tags: attribute,input, maxlength, text
---

<div class="divider-heading"></div>
