---
title: TODO
module: topic-05
todo: <i class="fas fa-check-square" aria-hidden="true"></i>
permalink: /topic-05/todo-form-intro/
tags: uncategorized
---

<div class="row text-center">
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <div class="list-group-item hw-item-disabled">
          <img class="icon-hw" src="../img/hw-icon-duckett.svg" />
          <h4 class="list-group-item-heading">Duckett<br />Ch 07: pgs 144-150</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 5 minute reading</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <a href="https://simfatic.com/forms/help/v40/how_does_an_html_form_work_.html" target="_blank" class="list-group-item">
          <i class="icon-hw fas fa-server" aria-hidden="true"></i>
          <h4 class="list-group-item-heading">How an HTML Form Works</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 5 minute reading</p>
        </a>
      </div>
    </div>
  </div>
</div>
