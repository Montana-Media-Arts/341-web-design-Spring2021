---
title: TODO
module: topic-05
todo: <i class="fas fa-check-square" aria-hidden="true"></i>
permalink: /topic-05/todo-form-input/
tags: uncategorized
---

<div class="row text-center">
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <div class="list-group-item hw-item-disabled">
          <img class="icon-hw" src="../img/hw-icon-duckett.svg" />
          <h4 class="list-group-item-heading">Duckett<br />Ch 07: pg 151</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 1 minute reading</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="bs-component">
      <div class="list-group">
        <a href="../../topic-02/protocols#tumblr" target="_blank" class="list-group-item">
          <i class="icon-hw fas fa-book-reader" aria-hidden="true"></i>
          <h4 class="list-group-item-heading">Review HTTP, HTML, & Logging Into Tumblr</h4>
          <div class="divider-hw"></div>
          <p class="list-group-item-text"><i class="far fa-clock" aria-hidden="true"></i> 7 minute activity</p>
        </a>
      </div>
    </div>
  </div>
</div>
