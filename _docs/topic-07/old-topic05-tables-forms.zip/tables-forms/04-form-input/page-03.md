---
title: 2. Type
module: topic-05
permalink: /topic-05/input-type/
tags: attribute, form, input, type
---

<div class="divider-heading"></div>


<div id="code-heading">Element Breakdown <i class="fas fa-battery-quarter"></i></div>
<pre id="breakdown-block">
<input <span class="pulsate">type=""</span> name="" id="" />
</pre>


By itself, the input element will not do anything. The input element requires the `type=""` to define the **type** of data it will collect, as well as how it will be displayed.
